#' @param seed Integer.
#'   Random seed.
#' @param n Positive integer.
#'   Sample size.
#' @param m Positive integer.
#'   Measurement occasions.
#' @param delta_t_gen Numeric.
#'   Time interval used to generate data.
#' @param sim R object.
#'   Output of the [IllustrationGenData()] function.
#' @param data R object.
#'   Output of the [IllustrationPrepData()] function.
#' @param fit R object.
#'   Fitted CT-VAR model.
#' @param R Positive integer.
#'   Number of Monte Carlo replications.
#' @param delta_t Numeric vector.
#'   Vector of time intervals.
#'
#' @param taskid Positive integer.
#'   Task ID.
#' @param repid Positive integer.
#'   Replication ID.
#' @param output_folder Character string.
#'   Output folder.
#' @param output_type Character string.
#'   Output type.
#'   Valid values include
#'   `"illustration-data"`,
#'   `"illustration-fit-dynr"`,
#'   `"illustration-dynr-delta-xmy"`,
#'   `"illustration-dynr-delta-std-xmy"`,
#'   `"illustration-dynr-mc-xmy"`, and
#'   `"illustration-dynr-mc-std-xmy"`.
#' @param suffix Character string.
#'   Output of `manCTMed:::.SimSuffix()`.
#' @param seed Integer.
#'   Random seed.
#' @param overwrite Logical.
#'   Overwrite existing output in `output_folder`.
#' @param integrity Logical.
#'   If `integrity = TRUE`,
#'   check for the output file integrity when `overwrite = FALSE`.
#' @param ci Logical.
#'   Run simulations for confidence intervals.
#'
#' @name TemplateIllustration
NULL
