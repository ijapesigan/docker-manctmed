# manCTMed 1.0.4

## Docker Hub Tag

* ijapesigan/manctmed:TAG

## Use

* Simulation:
  - Parametric bootstrap

# manCTMed 1.0.3

## Docker Hub Tag

* ijapesigan/manctmed:2025-02-22-07160838

## Use

* Illustration:
  - Delta method
  - Monte Carlo method
* Simulation:
  - Delta method
  - Monte Carlo method

## Code Changes

* Simulation:
  - Parametric bootstrap
  - Delta method
  - Monte Carlo method
  - Removed fit CT-VAR with `OpenMx`

# manCTMed 1.0.2

## Docker Hub Tag

* ijapesigan/manctmed:2025-02-20-07415917

## Use

* Illustration:
  - MC for Phi and Sigma

## Code Changes

* Illustration:
  - MC for Phi and Sigma

# manCTMed 1.0.1

## Docker Hub Tag

* ijapesigan/manctmed:2025-02-18-23083756

## Use

* Illustration:
  - Generate data.
  - Fit CT-VAR with `dynr`

## Code Changes

* Simulation:
  - Fit CT-VAR with `OpenMx`
* Illustration:
  - Generate data.
  - Fit CT-VAR with `dynr`
  - Fit CT-VAR with `OpenMx`
  - Extract estimated drift matrix with sampling covariance matrix
  - Extract estimated drift matrix and process noise covariance matrix with sampling covariance matrix

# manCTMed 1.0.0

## Docker Hub Tag

* ijapesigan/manctmed:2025-02-15-00234303

## Use

* Simulation:
  - Generate data.
  - Fit CT-VAR with `dynr`

## Code Changes

* Simulation:
  - Generate data.
  - Fit CT-VAR with `dynr`
