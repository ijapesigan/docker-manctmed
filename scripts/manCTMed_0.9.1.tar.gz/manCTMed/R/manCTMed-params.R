#' Simulation Parameters
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @format A dataframe with 20 rows and 2 columns:
#'
#' \describe{
#'   \item{taskid}{
#'     Simulation Task ID.
#'   }
#'   \item{n}{
#'     Sample size.
#'   }
#' }
#'
#' @keywords data parameters
"params"
