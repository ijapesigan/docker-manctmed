#' Plot Coverage Probabilities
#'
#' Coverage probabilities for the model \eqn{X \to M \to Y}.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param results Summary results data frame.
#' @param delta_t Vector of time-interval value.
#'   If `delta_t = NULL`, use all available time-intervals
#'
#' @examples
#' data(results, package = "manCTMed")
#' PlotCoverage(results)
#' PlotCoverage(results, delta_t = 1:14)
#' PlotCoverage(results, delta_t = 15:30)
#'
#' @family Figure Functions
#' @keywords manCTMed figure
#' @export
PlotCoverage <- function(results,
                         delta_t = NULL) {
  if (!is.null(delta_t)) {
    results <- results[which(results$interval %in% delta_t), ]
  }
  interval <- theta_hit <- NULL
  results <- results[which(results$xmy), ]
  Method <- as.character(
    results$method
  )
  Method <- ifelse(
    test = Method == "delta",
    yes = "Delta",
    no = Method
  )
  Method <- ifelse(
    test = Method == "mc",
    yes = "MC",
    no = Method
  )
  results$Method <- Method
  effect_label <- as.character(
    results$effect
  )
  effect_label <- ifelse(
    test = effect_label == "total",
    yes = "Total Effect",
    no = effect_label
  )
  effect_label <- ifelse(
    test = effect_label == "direct",
    yes = "Direct Effect",
    no = effect_label
  )
  effect_label <- ifelse(
    test = effect_label == "indirect",
    yes = "Indirect Effect",
    no = effect_label
  )
  results$effect_label <- effect_label
  results$n_label <- paste0(
    "n:",
    results$n
  )
  results$n_label <- factor(
    results$n_label,
    levels = c(
      paste0(
        "n:",
        sort(unique(results$n))
      )
    )
  )
  p <- ggplot2::ggplot(
    data = results,
    ggplot2::aes(
      x = interval,
      y = theta_hit,
      shape = Method,
      color = Method,
      group = Method,
      linetype = Method
    )
  ) +
    ggplot2::geom_hline(
      yintercept = 0.95,
      alpha = 0.5
    ) +
    ggplot2::geom_hline(
      yintercept = 0.925,
      alpha = 0.5
    ) +
    ggplot2::geom_hline(
      yintercept = 0.975,
      alpha = 0.5
    ) +
    ggplot2::annotate(
      geom = "rect",
      fill = "grey",
      alpha = 0.50,
      xmin = -Inf,
      xmax = Inf,
      ymin = 0.925,
      ymax = 0.975
    ) +
    ggplot2::geom_point() +
    ggplot2::geom_line() +
    ggplot2::facet_grid(
      n_label ~ effect_label
    ) +
    ggplot2::xlab(
      "Time-Interval"
    ) +
    ggplot2::ylab(
      "Coverage Probability"
    ) +
    ggplot2::theme_bw() +
    ggplot2::scale_color_brewer(palette = "Set1") +
    ggplot2::scale_shape()
  return(p)
}
