#' Simulation Parameters
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @format A list with the following elements:
#'
#' \describe{
#'   \item{phi}{
#'     The estimated drift matrix.
#'   }
#'   \item{vcov}{
#'     The estimated sampling variance-covariance matrix
#'     of the estimated drift matrix.
#'   }
#' }
#'
#' @keywords data empirical
"ryan2021phi"
