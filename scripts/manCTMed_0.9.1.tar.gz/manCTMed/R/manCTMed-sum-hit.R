#' Summarize Simulations - CI Hit
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a numeric matrix.
#'
#' @inheritParams Template
#' @export
#' @keywords manCTMed ci summary
SumHit <- function(taskid,
                   reps,
                   output_folder,
                   output_type,
                   params_taskid,
                   xmy,
                   ncores) {
  # Summary is limited to alpha = 0.05
  if (xmy) {
    parameter <- t(effects$xmy[, -1])
    dim(parameter) <- NULL
  } else {
    parameter <- t(effects$ymx[, -1])
    dim(parameter) <- NULL
  }
  foo <- function(repid,
                  taskid,
                  output_folder,
                  params_taskid,
                  parameter) {
    suffix <- .SimSuffix(
      taskid = taskid,
      repid = repid
    )
    fn_input <- SimFN(
      output_type = output_type,
      output_folder = output_folder,
      suffix = suffix
    )
    output <- summary(
      readRDS(fn_input),
      alpha = 0.05
    )
    output$effect <- c(1, 2, 3)
    output$n <- params_taskid$n
    output <- cbind(
      output,
      parameter = parameter
    )
    output$zero_hit <- (
      output[, "2.5%"] < 0
    ) & (
      0 < output[, "97.5%"]
    )
    output$theta_hit <- (
      output[, "2.5%"] < output[, "parameter"]
    ) & (
      output[, "parameter"] < output[, "97.5%"]
    )
  }
  out <- (
    1 / reps
  ) * Reduce(
    f = `+`,
    x = parallel::mclapply(
      X = seq_len(reps),
      FUN = foo,
      taskid = taskid,
      output_folder = output_folder,
      params_taskid = params_taskid,
      parameter = parameter,
      mc.cores = ncores
    )
  )
  return(
    cbind(
      out,
      taskid = taskid,
      replications = reps,
      output_type = output_type
    )
  )
}
