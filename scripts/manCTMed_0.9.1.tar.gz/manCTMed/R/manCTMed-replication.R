#' Simulation Replication
#'
#' Performs a single simulation replication involving the following:
#' - Data generation using the `simStateSpace` package.
#' - Model fitting using the `dynr` package.
#' - Generate delta method confidence intervals
#'   using the [cTMed::DeltaMed()] function.
#' - Generate Monte Carlo method confidence intervals
#'   using the [cTMed::MCMed()] function.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @inheritParams Data
#' @inheritParams CI
#' @param wd Working directory for output files.
#'
#' @family Simulation Functions
#' @keywords manCTMed
#' @export
Replication <- function(repid,
                        n,
                        wd,
                        delta_t = c(5, 10, 15, 20),
                        R = 20000L) {
  # path
  path <- file.path(
    wd,
    paste0(
      "n",
      "-",
      sprintf(
        "%05d",
        n
      )
    )
  )
  dir.create(
    path,
    showWarnings = FALSE,
    recursive = TRUE
  )
  # files
  fn_root <- file.path(
    path,
    paste0(
      "manCTMed",
      "-",
      "n",
      "-",
      sprintf(
        "%05d",
        n
      ),
      "-",
      "rep",
      "-",
      sprintf(
        "%05d",
        repid
      )
    )
  )
  fn <- paste0(
    fn_root,
    ".Rds"
  )
  if (file.exists(fn)) {
    check_file <- function(fn) {
      tryCatch(
        expr = {
          readRDS(fn)
          return(FALSE)
        },
        error = function(e) {
          return(TRUE)
        },
        warning = function(w) {
          return(TRUE)
        }
      )
    }
    run <- check_file(fn = fn)
  } else {
    run <- TRUE
  }
  if (run) {
    data <- Data(
      repid = repid,
      n = n
    )
    fit_dynr <- FitDynr(x = data)
    ci_dynr <- CI(x = fit_dynr)
    output <- list(
      data = data,
      fit_dynr = fit_dynr,
      ci_dynr = ci_dynr
    )
    saveRDS(
      output,
      file = fn,
      compress = "xz"
    )
  }
  return(
    paste(
      "repid:",
      repid,
      "n:",
      n
    )
  )
}
