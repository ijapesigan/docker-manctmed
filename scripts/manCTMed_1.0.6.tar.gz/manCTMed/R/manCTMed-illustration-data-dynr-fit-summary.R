#' Illustration Summary of Dynr Output
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @docType data
#' @name illustration_dynr_fit_summary
#' @usage data(illustration_dynr_fit_summary)
#' @format Output of the summary of the dynr package.
#'
#' @keywords data illustration
"illustration_dynr_fit_summary"
