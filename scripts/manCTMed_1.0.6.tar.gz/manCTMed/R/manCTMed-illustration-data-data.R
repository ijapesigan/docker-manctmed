#' Illustration Data
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @docType data
#' @name illustration_data
#' @usage data(illustration_data)
#' @format A dataframe with 13433 rows and 5 columns:
#'
#' \describe{
#'   \item{id}{
#'     Participant ID.
#'   }
#'   \item{time}{
#'     Time variable.
#'   }
#'   \item{x}{
#'     Conflict.
#'   }
#'   \item{m}{
#'     Knowledge.
#'   }
#'   \item{y}{
#'     Competence
#'   }
#' }
#'
#' @keywords data illustration
"illustration_data"
