#' Illustration Dynr Output
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @docType data
#' @name illustration_dynr_fit
#' @usage data(illustration_dynr_fit)
#' @format Outpur of [dynr::dynr.cook()].
#'
#' @keywords data illustration
"illustration_dynr_fit"
