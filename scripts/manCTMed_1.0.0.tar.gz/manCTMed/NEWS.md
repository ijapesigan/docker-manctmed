# manCTMed 1.0.0

* Generate data.
* Fit CT-VAR with `dynr`
