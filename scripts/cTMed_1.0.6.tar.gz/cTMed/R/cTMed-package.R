#' @aliases cTMed-package
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib cTMed, .registration = TRUE
## usethis namespace: end
NULL
