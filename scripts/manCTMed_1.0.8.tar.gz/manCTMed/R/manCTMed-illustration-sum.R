#' Summary (Illustration)
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return The output is saved as an external file in `output_folder`.
#'
#' @inheritParams TemplateIllustration
#' @export
#' @keywords manCTMed illustration
IllustrationSum <- function(tasks,
                            reps,
                            delta_t,
                            output_folder,
                            ncores) {
  # Do not include default arguments here.
  # All arguments should be set in `.sim/illustration-sim-args.R.R`.
  pwd <- getwd()
  on.exit(
    setwd(pwd)
  )
  replication <- function(taskid,
                          reps,
                          method,
                          std,
                          xmy,
                          delta_t,
                          output_folder,
                          ncores) {
    # Add taskid to output_folder
    output_folder <- file.path(
      output_folder,
      paste0(
        SimProj(),
        "-",
        "illustration",
        "-",
        sprintf(
          "%05d",
          taskid
        )
      )
    )
    setwd(output_folder)
    fn_root <- "manCTMed-illustration-dynr"
    if (std) {
      fn_method <- paste0(
        method,
        "-std-xmy"
      )
    } else {
      fn_method <- paste0(
        method,
        "xmy"
      )
    }
    if (xmy) {
      fn_method <- paste0(
        fn_method, "-",
        "xmy"
      )
    } else {
      fn_method <- paste0(
        fn_method, "-",
        "ymx"
      )
    }
    phi <- matrix(
      data = c(
        -0.138,
        -0.124,
        -0.057,
        0,
        -0.865,
        0.115,
        0,
        0.434,
        -0.693
      ),
      nrow = 3,
      ncol = 3
    )
    rownames(phi) <- colnames(phi) <- c(
      "x",
      "m",
      "y"
    )
    sigma <- 0.10 * diag(3)
    if (std) {
      theta <- summary(
        cTMed::MedStd(
          phi = phi,
          sigma = sigma,
          delta_t = delta_t,
          from = "x",
          to = "y",
          med = "m"
        )
      )[2:4]
    } else {
      theta <- summary(
        cTMed::Med(
          phi = phi,
          delta_t = delta_t,
          from = "x",
          to = "y",
          med = "m"
        )
      )[2:4]
    }
    coefs <- function(repid) {
      fn <- paste0(
        fn_root, "-",
        fn_method, "-",
        sprintf(
          "%05d",
          taskid
        ), "-",
        sprintf(
          "%05d",
          repid
        ),
        ".Rds"
      )
      x <- readRDS(
        fn
      )$output[[as.character(delta_t)]][["est"]]
      names(x) <- c(
        "total",
        "direct",
        "indirect"
      )
      x
    }
    ses <- function(repid) {
      fn <- paste0(
        fn_root, "-",
        fn_method, "-",
        sprintf(
          "%05d",
          taskid
        ), "-",
        sprintf(
          "%05d",
          repid
        ),
        ".Rds"
      )
      x <- sqrt(
        diag(
          readRDS(
            fn
          )$output[[as.character(delta_t)]][["vcov"]]
        )
      )
      names(x) <- c(
        "total",
        "direct",
        "indirect"
      )
      x
    }
    sq_error <- function(repid) {
      fn <- paste0(
        fn_root, "-",
        fn_method, "-",
        sprintf(
          "%05d",
          taskid
        ), "-",
        sprintf(
          "%05d",
          repid
        ),
        ".Rds"
      )
      (
        theta - readRDS(
          fn
        )$output[[as.character(delta_t)]][["est"]]
      )^2
    }
    coefs <- do.call(
      what = "rbind",
      args = parallel::mclapply(
        X = seq_len(reps),
        FUN = coefs,
        mc.cores = ncores
      )
    )
    ses <- do.call(
      what = "rbind",
      args = parallel::mclapply(
        X = seq_len(reps),
        FUN = ses,
        mc.cores = ncores
      )
    )
    sq_error <- do.call(
      what = "rbind",
      args = parallel::mclapply(
        X = seq_len(reps),
        FUN = sq_error,
        mc.cores = ncores
      )
    )
    theta_hat_bar <- colMeans(coefs)
    theta_hat_sd <- sqrt(diag(var(coefs)))
    theta_rmse <- colMeans(sq_error)
    theta_bias <- theta_hat_bar - theta
    se_hat_bar <- colMeans(ses)
    se_bias <- se_hat_bar - theta_hat_sd
    output <- data.frame(
      taskid = taskid,
      reps = reps,
      interval = delta_t,
      theta = theta,
      theta_hat_bar = theta_hat_bar,
      theta_hat_sd = theta_hat_sd,
      theta_rmse = theta_rmse,
      theta_bias = theta_bias,
      se_hat_bar = se_hat_bar,
      se_bias = se_bias,
      std = std,
      method = method
    )
    saveRDS(
      output,
      file = paste0(
        SimProj(),
        "-",
        "illustration",
        "-",
        "summary",
        "-",
        sprintf(
          "%05d",
          taskid
        )
      )
    )
    output
  }
  args <- expand.grid(
    taskid = seq_len(tasks),
    reps = reps,
    method = c(
      "delta",
      "mc",
      "boot-para"
    ),
    std = c(TRUE, FALSE),
    xmy = TRUE,
    delta_t = delta_t,
    output_folder = output_folder,
    ncores = ncores
  )
  do.call(
    what = "rbind",
    args = mapply(
      FUN = replication,
      taskid = args$taskid,
      reps = rargs$eps,
      method = args$method,
      std = args$std,
      xmy = args$xmy,
      delta_t = args$delta_t,
      output_folder = args$output_folder,
      ncores = args$ncores
    )
  )
}
