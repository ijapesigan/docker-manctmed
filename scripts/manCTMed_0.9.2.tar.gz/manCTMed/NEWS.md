# manCTMed 0.9.2

* First revision.

# manCTMed 0.9.1

* Initial setup
