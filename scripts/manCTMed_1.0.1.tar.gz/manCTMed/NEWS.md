# manCTMed 1.0.1

* Simulation:
  - Generate data.
  - Fit CT-VAR with `dynr`
  - Fit CT-VAR with `OpanMx`
* Illustration:
  - Generate data.
  - Fit CT-VAR with `dynr`
  - Fit CT-VAR with `OpenMx`

# manCTMed 1.0.0

* Simulation:
  - Generate data.
  - Fit CT-VAR with `dynr`
