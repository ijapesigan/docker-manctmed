#' Prepare Data Before Model Fitting (Illustration)
#'
#' The function converts the output of [IllustrationGenData()]
#' into a data frame.
#'
#' @inheritParams TemplateIllustration
#'
#' @examples
#' \dontrun{
#' sim <- IllustrationGenData(seed = 42)
#' data <- IllustrationPrepData(sim)
#' head(data)
#' dim(data)
#' # Subsample
#' sim <- IllustrationGenData(seed = 42, m = 10001)
#' data <- IllustrationPrepData(sim, subsample = TRUE)
#' head(data)
#' dim(data)
#' }
#' @family Model Fitting Functions
#' @keywords manCTMed fit illustration
#' @import dynr
#' @importFrom stats coef
#' @export
IllustrationPrepData <- function(sim,
                                 subsample = FALSE) {
  data <- as.data.frame(sim)
  colnames(data) <- c(
    "id",
    "time",
    "x",
    "m",
    "y"
  )
  if (subsample) {
    data[
      !(
        data$time %% 10 == 0
      ),
      setdiff(
        x = names(data),
        y = c("time", "id")
      )
    ] <- NA
  }
  data
}
