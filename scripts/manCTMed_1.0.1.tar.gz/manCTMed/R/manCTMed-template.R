#' @param sim R object.
#'   Output of the [GenData()] function.
#' @param data R object.
#'   Output of the [RandomMeasurement()] function.
#'
#' @param taskid Positive integer.
#'   Task ID.
#' @param repid Positive integer.
#'   Replication ID.
#' @param output_folder Character string.
#'   Output folder.
#' @param output_type Character string.
#'   Output type.
#'   Valid values include
#'   `"data"`,
#'   `"fit-dynr"`, and
#'   `"fit-mx"`
#' @param suffix Character string.
#'   Output of `manCTMed:::.SimSuffix()`.
#' @param seed Integer.
#'   Random seed.
#' @param overwrite Logical.
#'   Overwrite existing output in `output_folder`.
#' @param integrity Logical.
#'   If `integrity = TRUE`,
#'   check for the output file integrity when `overwrite = FALSE`.
#'
#' @name Template
NULL
